//Devin Perry - CS300 - Project 2 CPP File - 8/11/2023
#include <algorithm>
#include <iostream>
#include <fstream>
#include <time.h>
#include <vector>
#include "CSVparser.hpp"

using namespace std;

//Defining the structure of a course 
struct Course{
string courseNumber;
string name;
vector<string> prerequisites;
};

//Function to split the list of strings into tokens
vector<string> tokenize(string s, string del = "")
{
    vector<string>stringArray;
    int start = 0;
    int end = s.find(del);
    while (end != -1) {
        stringArray.push_back(s.substr(start, end - start));
        start = end + del.size();
        end = s.find(del, start);
    }
    stringArray.push_back(s.substr(start, end - start));
    return stringArray;
}

//Function to load data structure
vector<Course> LoadDataStructure()
{
    //Calling the text from the abcu.txt file
    ifstream fin("abcu.txt", ios::in);
    vector<Course> courses;
    string line;
    //Beginning a loop
    while (1)
    {
        getline(fin, line);
        //If end of file is reached break loop
        if (line == "-1")
            break;
        Course course;
        //Getting the information that was tokenized from earlier
        vector<string> tokenizedInformation = tokenize(line, ",");
        //Storing the objects in the data structure
        course.courseNumber = tokenizedInformation[0];
        course.name = tokenizedInformation[1];
        //If there is prerequisites, handle them
        for (int i = 2; i < tokenizedInformation.size(); i++)
        {
        course.prerequisites.push_back(tokenizedInformation[i]);
        }
        courses.push_back(course);
    }
    fin.close();
    return courses;
}

void printCourse(Course course)
{
    string courseNumber = course.courseNumber;
    string name = course.name;
    vector<string> prerequisites = course.prerequisites;
        //Outputting the course information that was called
        cout << "Course Number: " << courseNumber << endl;
        cout << "Course Name: " << name << endl;
        cout << "Prerequisaites: ";
        for (int i = 0; i < prerequisites.size(); i++)
            {
            cout << prerequisites[i] << " ";
            }
        cout << "\n\n";
    }

void printCourseList(vector<Course> courses)
{
    //Sorting the information
    int n = courses.size();
    for (int i = 0; i < n - 1; i++)
        {
            for (int j = 0; j < n - i - 1; j++)
            {
                if (courses[j].courseNumber > courses[j + 1].courseNumber)
                {
                swap(courses[j + 1], courses[j]);
                }
            }
        }
    //Reading every course's information and then printing it
    for (int i = 0; i < n; i++)
    {
        printCourse(courses[i]);
    }
}

void searchCourse(vector<Course> courses)
{
    int n = courses.size();
    string courseNumber;
    int f = 0;
    cout << "What course do you want to know about? (Enter the course number): ";
    cin >> courseNumber;
    for (int i = 0; i < n; i++)
    {
        //If course is found, print it
        if (courses[i].courseNumber == courseNumber)
        {
            f = 1;
            printCourse(courses[i]);
            break;

        }
    }
    //If course is not found, print error message
    if (f == 0)
        {
        cout << "A course with the given course number cannot be found.\n";
        }
}

int main(int argc, char** argv)
{
    vector<Course> courses;
    //Menu of options
    cout << "1.Load Data Structure.\n";
    cout << "2.Print Course List.\n";
    cout << "3.Print Course.\n";
    cout << "4.Exit\n";
    int ch;
    //Making each option do something
    do {
        cout<< "\nWhat would you like to do? ";
        cin >> ch;
        switch (ch)
        {
            case 1: courses = LoadDataStructure(); break;
            case 2: printCourseList(courses); break;
            case 3: searchCourse(courses); break;
            case 4: cout << "Thank you for using the course planner!\n"; break;
            //If not 1, 2, 3, or 4 then print error message
            default: cout << "That is not a valid input. Please try again using the numbers 1, 2, 3, or 4.\n";
        }
    } while (ch != 4);
    return 0;
}